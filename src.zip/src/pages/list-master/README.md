# List Master

The List Master Page shows the details of instances of `Item`, and will most commonly be navigated to from `ListMasterPage`.


## 

https://stackoverflow.com/a/30980293/2044080
https://cordova.apache.org/docs/en/5.1.1/guide/platforms/android/tools.html
